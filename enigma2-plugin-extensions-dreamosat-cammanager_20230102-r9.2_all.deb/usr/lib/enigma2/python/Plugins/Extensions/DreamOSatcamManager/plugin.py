#!/usr/bin/env python
# -*- coding: utf-8 -*-

# python3
from __future__ import print_function
# for localized messages
try:
    from . import _
except:
    pass

#
# DreamOSat camManager Plugin by 
#
#####################################################
#  Coded by pcd@i-have-a-dreambox, October 2010     #
#  modified by. audi06_19           2017 - 2023     #
#  Support: www.dreamosat-forum.com                 #
#  E-Mail: info@dreamosat-forum.com                 #
#####################################################
from array import array
from Components.ActionMap import ActionMap
from Components.ActionMap import NumberActionMap
from Components.Button import Button
from Components.config import config
from Components.config import configfile
from Components.config import ConfigSubsection
from Components.config import ConfigText
from Components.config import ConfigYesNo
from Components.config import getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.FileList import FileList
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryPixmapAlphaTest
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from Components.PluginComponent import plugins
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from datetime import datetime
from enigma import eConsoleAppContainer
from enigma import eDVBDB
from enigma import eListboxPythonMultiContent
from enigma import ePicLoad
from enigma import eTimer
from enigma import getDesktop
from enigma import gFont
from enigma import iServiceInformation
from enigma import loadPNG
from enigma import RT_HALIGN_CENTER
from enigma import RT_HALIGN_LEFT
from enigma import RT_HALIGN_RIGHT
from enigma import RT_VALIGN_CENTER
from enigma import RT_WRAP
from os import chmod
from os import environ
from os import listdir
from os import mkdir
from os import path
from os import remove
from os import rename
from os import symlink
from os import system
from os import walk
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.PluginBrowser import PluginBrowser
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from ServiceReference import ServiceReference
from string import hexdigits
from time import sleep
from Tools.BoundFunction import boundFunction
from Tools.Directories import *
from Tools.Directories import copyfile
from Tools.Directories import fileExists
from Tools.Directories import pathExists
from Tools.Directories import resolveFilename
from Tools.Directories import SCOPE_LANGUAGE
from Tools.Directories import SCOPE_PLUGINS
from Tools.Directories import SCOPE_SKIN_IMAGE
#from Tools.GetEcmInfo import GetEcmInfo
from Tools import Notifications
from Tools.LoadPixmap import LoadPixmap
from twisted.web.client import getPage
from xml.dom import minidom
from xml.dom import Node
from base64 import b64encode, b64decode
import base64
import binascii
import os
import shutil
import sys
import time
import urllib

plugin_dir = resolveFilename(SCOPE_PLUGINS, "Extensions/DreamOSatcamManager/")

from sys import version_info
if sys.version_info[0] == 3:
    from urllib.request import urlopen as compat_urlopen
    from urllib.request import Request as compat_Request
    from urllib.request import urlretrieve
    from urllib.error import URLError as compat_URLError
    from http.client import HTTPException
else:
    # Not Python 3 - today, it is most likely to be Python 2
    # But note that this might need an update when Python 4
    # might be around one day
    from urllib2 import urlopen as compat_urlopen
    from urllib2 import Request as compat_Request
    from urllib import urlretrieve
    from urllib2 import URLError as compat_URLError
    from httplib import HTTPException

reswidth = getDesktop(0).size().width()
resheight = getDesktop(0).size().height()
sz_w = getDesktop(0).size().width()

REDC = '\033[31m'
ENDC = '\033[m'
def cprint(text):
    print(REDC + "[DreamOSat camManager] " + text + ENDC)
################################################################################################# 
import ssl
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
#####################################################################
INFOBILGI = 'Dreambox\nVu + Plus\nOctagon\nGigablue\nMut@nt\nETrend\nFormuler\nEdisionOS\nGolden\nWetek\n---------------\nSupport\nDreamOSat\nForum\n---------------\n'
DATE_VERSION = '20220101-r9.1'
AUTHOR = 'By audi06_19 admin@dreamosat-forum.com'

def show_list(h):
    png1 = plugin_dir + "on.png"
    png2 = plugin_dir + "off.png"
    cond = readCurrent_1()
    if reswidth == 1280:
        res = [(h)]
        if cond == h:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(0, 5), size=(60, 30), png=loadPNG(png1)))
            res.append(MultiContentEntryText(pos=(65, 2), size=(698, 40), font=4, text=h + '  (Active)', color = 0xadff00 , flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))

        else:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(0, 5), size=(60, 30), png=loadPNG(png2)))
            res.append(MultiContentEntryText(pos=(65, 2), size=(698, 40), font=3, text=h, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))
        return res
    else:
        res = [(h)]
        if cond == h:
            res.append(MultiContentEntryText(pos=(65, 5), size=(625, 50), font=9, text=h + '  (Active)', color = 0xadff00, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))
            res.append(MultiContentEntryPixmapAlphaTest(pos=(0, 15), size=(60, 30), png=loadPNG(png1)))
        else:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(0, 15), size=(60, 30), png=loadPNG(png2)))
            res.append(MultiContentEntryText(pos=(65, 5), size=(625, 50), font=8, text=h, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))
        return res

class webList(MenuList):
    def __init__(self, list):
        MenuList.__init__(self, list, True, eListboxPythonMultiContent)
        if reswidth == 1280:
            self.l.setItemHeight(40)
            self.l.setFont(0, gFont('Regular', 23))
        else:
            self.l.setItemHeight(60)
            self.l.setFont(0, gFont('Regular', 36))

def showlist(data, list):
    icount = 0
    plist = []
    for line in data:
        name = data[icount]
        plist.append(show_list_1(name))
        icount = icount + 1
        list.setList(plist)

def show_list_1(h):
    if reswidth == 1280:
        res = [h]
        res.append(MultiContentEntryText(pos=(2, 2), size=(670, 40), font=3, text=h, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP))
    else:
        res = [h]
        res.append(MultiContentEntryText(pos=(2, 2), size=(625, 60), font=8, text=h, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP))
    return res

class m2list(MenuList):
    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', 16))
        self.l.setFont(1, gFont('Regular', 20))
        self.l.setFont(2, gFont('Regular', 22))
        self.l.setFont(3, gFont('Regular', 24))
        self.l.setFont(4, gFont('Regular', 26))
        self.l.setFont(5, gFont('Regular', 28))
        self.l.setFont(6, gFont('Regular', 30))
        self.l.setFont(7, gFont('Regular', 32))
        self.l.setFont(8, gFont('Regular', 34))
        self.l.setFont(9, gFont('Regular', 38))
        if reswidth == 1280:
            self.l.setItemHeight(40)
        else:
            self.l.setItemHeight(60)

class DreamOSatEmumanager(Screen):
    if reswidth == 1920:
        skin = """
            <screen name="DreamOSatEmumanager" position="center,center" size="1050,760" title="">
                <widget name="list" position="30,10" size="690,240" transparent="1" zPosition="3" scrollbarMode="showOnDemand"/>
                <widget name="info" position="70,270" size="660,380" transparent="1" font="Regular;28" shadowColor="black" foregroundColor="#DBA901" halign="left"/>
                
                <eLabel position="10,680"  size="250,2" backgroundColor="red" />
                <eLabel position="270,680" size="250,2" backgroundColor="green" />
                <eLabel position="530,680" size="250,2" backgroundColor="yellow" />
                <eLabel position="790,680" size="250,2" backgroundColor="blue" />
                
                <widget name="key_red" position="10,680" size="250,65" font="Regular;32" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                <widget name="key_green" position="270,680" size="250,65" font="Regular;28" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                <widget name="key_yellow" position="530,680" size="250,65" font="Regular;28" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                <widget name="key_blue" position="790,680" size="250,65" font="Regular;28" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                
                <widget source="global.CurrentTime" render="Label" position="740,30" size="260,20" font="Regular;22" foregroundColor="#fff700" transparent="0" zPosition="5" halign="center" valign="center" backgroundColor="#101010">
                    <convert type="ClockToText">Format:%A  %d.%m.%Y</convert>
                </widget>
                <widget source="global.CurrentTime" render="Label" position="740,50" size="260,40" font="Regular;22" foregroundColor="#fff700" transparent="0" zPosition="5" halign="center" valign="center" backgroundColor="#101010">
                    <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <widget name="INFOBILGI" position="740,120" size="260,500" font="Regular;26" halign="center" valign="center"/>
                <widget name="version" position="740,620" size="260,28" font="Regular;26" halign="center" valign="center"/>
            </screen>"""
    else:
        skin = """
            <screen name="DreamOSatEmumanager" position="center,center" size="750,550" title="">
                <widget name="list" position="20,10" size="530,160" transparent="1" zPosition="3" scrollbarMode="showOnDemand"/>
                <widget name="info" position="50,190" size="480,290" transparent="1" font="Regular;20" shadowColor="black" foregroundColor="#DBA901" halign="left"/>

                <eLabel position="10,480"  size="175,2" backgroundColor="red" />
                <eLabel position="195,480" size="175,2" backgroundColor="green" />
                <eLabel position="380,480" size="175,2" backgroundColor="yellow" />
                <eLabel position="565,480" size="175,2" backgroundColor="blue" />

                <widget name="key_red" position="10,480" size="175,50" font="Regular;24" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                <widget name="key_green" position="195,480" size="175,50" font="Regular;22" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                <widget name="key_yellow" position="380,480" size="175,50" font="Regular;22" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
                <widget name="key_blue" position="565,480" size="175,50" font="Regular;22" zPosition="3" valign="center" halign="center" foregroundColor="white" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />

                <widget source="global.CurrentTime" render="Label" position="560,5" size="185,20" font="Regular;16" foregroundColor="#fff700" transparent="0" zPosition="5" halign="center" valign="center" backgroundColor="#101010">
                    <convert type="ClockToText">Format:%A  %d.%m.%Y</convert>
                </widget>
                <widget source="global.CurrentTime" render="Label" position="560,25" size="185,20" font="Regular;16" foregroundColor="#fff700" transparent="0" zPosition="5" halign="center" valign="center" backgroundColor="#101010">
                    <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <widget name="INFOBILGI" position="560,60" size="140,400" font="Regular;20" halign="center" valign="center"/>
                <widget name="version" position="570,450" size="140,20" font="Regular;16" halign="center" valign="center"/>
            </screen>"""

    def __init__(self, session, args=False):
        Screen.__init__(self, session)
        self.skinName = 'DreamOSatEmumanager'
        self.index = 0
        self.emulist = []
        self.namelist = []
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'InfobarEPGActions'],
        {
         'ok': self.action,
         'cancel': self.close,
         'green': self.action,
         'red': self.stop,
         'yellow': self.Keyupdater
        }, -1)
        self['key_green'] = Label(_('Start/Restart'))
        self['key_red'] = Label(_('Stop'))
        self['key_yellow'] = Label(_('SoftCam.Key\nUpdater'))
        self['key_blue'] = Label('')
        try:
            from Plugins.Extensions.DreamOSatDownloader.plugin import DreamOSatDownloader
            self['actionsDreamOSatDownloader'] = ActionMap(['ColorActions'],
             {'blue': self.callDreamOSatDownloader}, -1)
            self['key_blue'].setText(_('DreamOSat\nDownload'))
        except:
            pass

        try:
            from Plugins.GP4.geminioscaminfo.goscaminfo import OScamList
            self['actionsoscamstatus'] = ActionMap(['InfobarEPGActions'],
             {'showEventInfo': self.callOscamStatus}, -1)
        except:
            pass

        try:
            from Plugins.Extensions.OscamStatus.plugin import OscamStatus
            self['actionsoscamstatus'] = ActionMap(['InfobarEPGActions'],
             {'showEventInfo': self.callOscamStatus}, -1)
        except:
            pass

        self['INFOBILGI'] = Label(_(INFOBILGI))
        self['version'] = Label(_('V. %s' % DATE_VERSION))
        self.lastCam = self.readCurrent()
        self.softcamlist = []
        self['info'] = Label()
        #self['list'] = MenuList(self.softcamlist)
        self["list"] = m2list([])
        self.readScripts()
        title = _('DreamOSat CamManager') + ' (' + DATE_VERSION + ')'
        self.setTitle(title)
        self.ecmTimer = eTimer()
        self.ecmTimer.start(100, 1)
        try:
            self.ecmTimer_conn = self.ecmTimer.timeout.connect(self.ecm)
        except:
            self.ecmTimer.callback.append(self.ecm)

        self.onShown.append(self.ecm)
        self.onHide.append(self.stopEcmTimer)

    def Keyupdater(self):
        self.session.open(DreamOSatkeyUpdater)

    def stopEcmTimer(self):
        self.ecmTimer.stop()

    def callDreamOSatDownloader(self):
        from Plugins.Extensions.DreamOSatDownloader.plugin import DreamOSatDownloader
        self.session.open(DreamOSatDownloader)

    def callOscamStatus(self):
        try:
            from Plugins.GP4.geminioscaminfo.goscaminfo import OScamList
            self.session.open(OScamList)
        except:
            from Plugins.Extensions.OscamStatus.plugin import OscamStatus
            self.session.open(OscamStatus)

    def getLastIndex(self):
        a = 0
        cprint(' 0000 ' + ' getLastIndex')
        if len(self.namelist) > 0:
            cprint(' 1111 ' + str(self.namelist) + ' getLastIndex')
            for x in self.namelist:
                cprint(' 2222 ' + str(x) + ' getLastIndex')
                cprint(' 3333 ' + str(self.lastCam) + ' getLastIndex')
                try:
                    self.lastCam = base64.b64decode(self.lastCam).decode("utf-8")
                    cprint(' 4444 ' + str(self.lastCam) + ' getLastIndex')
                except:
                    pass
                if x == self.lastCam:
                    cprint(' 5555 ' + str(x) + ' getLastIndex')
                    return a
                a += 1
        else:
            return -1
        return -1

    def action(self):
        self.session.nav.playService(None)
        last = self.getLastIndex()
        var = self['list'].getSelectionIndex()
        if last > -1:
            if last == var:
                self.cmd_1 = '/usr/camscript/' + self.emulist[var] + ' cam_res &'
                os.system(self.cmd_1)
                sleep(0.25)
                #cprint('/usr/camscript/' + self.emulist[var] + ' cam_res (01)')
            else:
                self.cmd_1 = '/usr/camscript/' + self.emulist[last] + ' cam_down &'
                os.system(self.cmd_1)
                sleep(0.25)
                #cprint('/usr/camscript/' + self.emulist[var] + ' stop (02)')
                ##
                self.cmd_1 = '/usr/camscript/' + self.emulist[var] + ' cam_up &'
                os.system(self.cmd_1)
                #cprint('/usr/camscript/' + self.emulist[var] + ' restart (03)')
        else:
            try:
                self.cmd_1 = '/usr/camscript/' + self.emulist[var] + ' cam_up &'
                os.system(self.cmd_1)
                sleep(0.25)
                #cprint('/usr/camscript/' + self.emulist[var] + ' start (04)')
            except:
                #cprint('############   hata   #################')
                pass

        if last != var:
            try:
                if sys.version_info[0] == 3:
                    data = self.namelist[var]
                    self.lastCam = base64.b64encode(data.encode("UTF-8")).decode("UTF-8")
                    cprint(self.namelist[var] + ' (05)')
                    self.writeFile()
                else:
                    self.lastCam = self.namelist[var]
                    cprint(self.namelist[var] + ' (05)')
                    self.writeFile()
            except:
                cprint(' (05 2)')
                pass

        self.readScripts()
        self.session.nav.playService(self.oldService)
        return

    def writeFile(self):
        if self.lastCam is not None:
            clist = open('/etc/clist.list', 'w')
            clist.write(str(self.lastCam))
            clist.close()
        stcam = open('/etc/startcam.sh', 'w')
        stcam.write('#!/bin/sh\n' + str(self.cmd_1))
        stcam.close()
        self.cmd_2 = '/etc/startcam.sh'
        os.chmod(self.cmd_2, 0o777)
        #cprint('created /etc/startcam.sh')
        return

    def stop(self):
        self.session.nav.playService(None)
        last = self.getLastIndex()
        cprint('0000' + ' stop')
        if last > -1:
            cprint('1111' + ' stop')
            ordu = self.emulist[last]
            self.cmd_1 = '/usr/camscript/' + ordu + ' cam_down &'
            os.system(self.cmd_1)
            cprint('2222' + ' stop')
            #cprint('/usr/camscript/' + ordu + ' stop')
            #self.session.openWithCallback(self.callback, MessageBox, _('Stop Camd: ' + str(self.namelist[last])), type=1, timeout=9)
        else:
            pass
        cprint('3333' + ' stop')
        self.lastCam = "no"
        self.cmd_1 = "# No list emulator"
        self.writeFile()
        sleep(0.25)
        self.readScripts()
        self["info"].setText(" ")
        self.session.nav.playService(self.oldService)
        cprint('4444' + ' stop')

    def readScripts(self):
        self.index = 0
        scriptlist = []
        pliste = []
        path = '/usr/camscript/'
        for root, dirs, files in os.walk(path):
            for name in files:
                scriptlist.append(name)
                self.cmd_3 = "dos2unix " + path + name
                os.system(self.cmd_3)
                #os.chmod(self.cmd_3, 0o777)

        self.emulist = scriptlist
        i = len(self.softcamlist)
        del self.softcamlist[0:i]
        for lines in scriptlist:
            dat = path + lines
            if sys.version_info[0] == 3:
                sfile = open(dat, 'r', encoding='UTF-8')
            else:
                sfile = open(dat, 'r')
            for line in sfile:
                if line[0:3] == 'OSD':
                    nam = line[5:len(line) - 2]
                    cprint('We are in Emumanager readScripts 2 nam = ' + nam)
                    if self.lastCam is not None:
                        if nam == self.lastCam:
                            self.softcamlist.append(show_list(nam))
                        else:
                            self.softcamlist.append(show_list(nam))
                    else:
                        self.softcamlist.append(show_list(nam))
                    self.index += 1
                    pliste.append(nam)

            sfile.close()
            self['list'].setList(self.softcamlist)
            self.namelist = pliste

        return

    def readCurrent(self):
        lastCam = ""
        Fileclist = ""
        if fileExists("/etc/CurrentBhCamName"):
            Fileclist = "/etc/CurrentBhCamName"
        else:
            Fileclist = "/etc/clist.list"
        try:
            if sys.version_info[0] == 3:
                with open(Fileclist) as f:
                    base3 = f.read()
                    f.close()
                sclist = base64.b64decode(base3).decode("utf-8")
            else:
                #sclist = open(Fileclist, "r")
                with open(Fileclist) as f:
                    base3 = f.read()
                    f.close()
                sclist = base3
        except:
            return None

        if sclist is not None:
            lastCam = sclist
            #for line in sclist:
            #    lastCam = line

        return lastCam

    def ecm(self):
        ecmf = ''
        if os.path.isfile('/tmp/ecm.info') is True:
            #myfile = open('/tmp/ecm.info', 'r')
            myfile = open('/tmp/ecm.info')
            ecmf = ''
            for line in myfile.readlines():
                print(line)
                ecmf = ecmf + line

            myfile.close()
            self['info'].setText(ecmf)
        else:
            self['info'].setText(ecmf)
        self.ecmTimer.start(5000, True)

    def autocam(self):
        current = None
        try:
            if sys.version_info[0] == 3:
                with open('/etc/clist.list') as f:
                    base2 = f.read()
                    f.close()
                aclist = base64.b64decode(base2).decode("utf-8")
            else:
                with open('/etc/clist.list') as f:
                    base2 = f.read()
                    f.close()
                    aclist = base2
        except:
            cprint('found list')
            return

        if aclist is not None:
            current = aclist
            """
            if sys.version_info[0] == 3:
                current = aclist
            else:
                for line in aclist:
                    current = line
            """
        print('current =', current)
        if os.path.isfile('/etc/autocam.txt') is False:
            alist = open('/etc/autocam.txt', 'w')
            alist.close()
        self.cleanauto()
        alist = open('/etc/autocam.txt', 'a')
        alist.write(self.oldService.toString() + '\n')
        last = self.getLastIndex()
        alist.write(current + '\n')
        alist.close()
        self.session.openWithCallback(self.callback, MessageBox, _('Autocam assigned to the current channel.'), type=1, timeout=10)
        return

    def cleanauto(self):
        delemu = 'no'
        if os.path.isfile('/etc/autocam.txt') is False:
            return
        myfile = open('/etc/autocam.txt', 'r')
        myfile2 = open('/etc/autocam2.txt', 'w')
        icount = 0
        for line in myfile.readlines():
            cprint('We are in Emumanager line, self.oldService.toString() = ' + line + self.oldService.toString())
            if line[:-1] == self.oldService.toString():
                delemu = 'yes'
                icount = icount + 1
                continue
            if delemu == 'yes':
                delemu = 'no'
                icount = icount + 1
                continue
            myfile2.write(line)
            icount = icount + 1

        myfile.close()
        myfile2.close()
        os.remove('/etc/autocam.txt')
        shutil.copy2('/etc/autocam2.txt', '/etc/autocam.txt')

def startConfig(session, **kwargs):
    session.open(DreamOSatEmumanager)

def mainmenu(menuid):
    if menuid != 'setup':
        return []
    else:
        return [
         (
          _('DreamOSat CamManager'), startConfig, 'softcam', None)]
        return

def autostart(reason, session=None, **kwargs):
    """called with reason=1 to during shutdown, with reason=0 at startup?"""
    cprint('[Softcam] Started')
    if reason == 0:
        if os.path.exists('/usr/bin/dccamd'):
            os.rename('/usr/bin/dccamd', '/usr/bin/dccamdOrig')
        if os.path.exists('/usr/camscript/Ncam_Ci.sh'):
            os.system('rm -rf /usr/camscript/*.sh')
        if os.path.exists('/etc/startcam.sh'):
            os.system('/etc/startcam.sh &')
            sleep(0.25)
            cprint('/etc/startcam.sh Started')
    else:
        cprint('/etc/startcam.sh autostart NO')
        pass

def main(session, **kwargs):
    session.open(DreamOSatEmumanager)


def StartSetup(menuid):
    if menuid == 'mainmenu':
        return [(_('DreamOSat CamManager'), main, 'softcam', 44)]
    else:
        return []


def Plugins(**kwargs):
    return [
     PluginDescriptor(name=_('DreamOSat CamManager'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
     PluginDescriptor(name=_('DreamOSat CamManager'), where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart),
     PluginDescriptor(name=_('DreamOSat CamManager'), description=_('Emulator Softcam, download manager.' + ' (' + DATE_VERSION + ')'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=startConfig)]

def readCurrent_1():
    lastCam = ""
    Fileclist = ""
    if fileExists("/etc/CurrentBhCamName"):
        Fileclist = "/etc/CurrentBhCamName"
    else:
        Fileclist = "/etc/clist.list"
    try:
        if sys.version_info[0] == 3:
            #eclist = open(Fileclist, "r", encoding='UTF-8')
            with open(Fileclist) as f:
                base1 = f.read()
                f.close()
            eclist = base64.b64decode(base1).decode("utf-8")
        else:
            #eclist = open(Fileclist, "r")
            with open(Fileclist) as f:
                base1 = f.read()
                f.close()
            eclist = base1
    except:
        return None
    if not eclist is None:
        lastCam = eclist
        #for line in eclist:
        #    lastCam = line
    return lastCam
########################################################
class DreamOSatkeyUpdater(Screen):
    skin_oe25 = """
    <screen name="DreamOSatkeyUpdater" position="center,center" size="850,450">
        <widget name="myText" position="10,0" size="833,94" valign="center" halign="center" zPosition="2" foregroundColor="white" font="Regular;26"/>
        <widget name="myMenu" position="10,120" size="833,240" scrollbarMode="showOnDemand" itemHeight="48"/>
        <widget name="about" position="400,400" size="440,40" valign="center" halign="center" zPosition="2" foregroundColor="blue" font="Regular;18"/>
        <widget name="myRedBtn" position="14,393" size="200,40" backgroundColor="red" valign="center" halign="center" zPosition="2" foregroundColor="white" font="Regular;30"/>
        <widget name="myGreenBtn" position="224,393" size="200,40" backgroundColor="green" valign="center" halign="center" zPosition="2" foregroundColor="white" font="Regular;30"/>
        <eLabel name="" position="10,108" size="833,1" backgroundColor="blue"/>
        <eLabel name="" position="10,376" size="833,1" backgroundColor="blue"/>
    </screen>"""
    skin_oe20 = """
    <screen name="DreamOSatkeyUpdater" position="center,center" size="850,450">
        <widget name="myText" position="10,0" size="833,94" valign="center" halign="center" zPosition="2" foregroundColor="white" font="Regular;26"/>
        <widget name="myMenu" position="10,120" size="833,240" scrollbarMode="showOnDemand" font="Regular;32" itemHeight="48"/>
        <widget name="about" position="400,400" size="440,40" valign="center" halign="center" zPosition="2" foregroundColor="blue" font="Regular;18"/>
        <widget name="myRedBtn" position="14,393" size="200,40" backgroundColor="red" valign="center" halign="center" zPosition="2" foregroundColor="white" font="Regular;30"/>
        <widget name="myGreenBtn" position="224,393" size="200,40" backgroundColor="green" valign="center" halign="center" zPosition="2" foregroundColor="white" font="Regular;30"/>
        <eLabel name="" position="10,108" size="833,1" backgroundColor="blue"/>
        <eLabel name="" position="10,376" size="833,1" backgroundColor="blue"/>
    </screen>"""
    Ver = '2.7'

    def __init__(self, session, args=0):
        Screen.__init__(self, session)
        if fileExists('/var/lib/dpkg/status') or fileExists('/var/lib64/dpkg/status'):
            self.setTitle(_('SoftCam.Key Updater v.%s -- OE 2.5/2.6') % self.Ver)
            self.skin = DreamOSatkeyUpdater.skin_oe25
        else:
            self.setTitle(_('SoftCam.Key Updater v.%s -- OE 2.0') % self.Ver)
            self.skin = DreamOSatkeyUpdater.skin_oe20
        list = []
        list.append((_(' /etc/tuxbox/config/'), '/etc/tuxbox/config/'))
        list.append((_(' /etc/tuxbox/config/oscam/'), '/etc/tuxbox/config/oscam/'))
        list.append((_(' /etc/tuxbox/config/oscam-emu/'), '/etc/tuxbox/config/oscam-emu/'))
        list.append((_(' /etc/tuxbox/config/oscam-trunk/'), '/etc/tuxbox/config/oscam-trunk/'))
        list.append((_(' /etc/tuxbox/config/ncam/'), '/etc/tuxbox/config/ncam/'))
        list.append((_(' /etc/tuxbox/config/gcam/'), '/etc/tuxbox/config/gcam/'))
        list.append((_(' /etc/tuxbox/config/TEST/'), '/etc/tuxbox/config/TEST/'))
        list.append((_(' /etc/tuxbox/config/ccache/'), '/etc/tuxbox/config/ccache/'))
        list.append((_(' /etc/tuxbox/config/oscam_emu/'), '/etc/tuxbox/config/oscam_emu/'))
        list.append((_(' /etc/tuxbox/config_emu/'), '/etc/tuxbox/config_emu/'))
        list.append((_(' /etc/'), '/etc/'))
        list.append((_(' /etc/keys/'), '/etc/keys/'))
        list.append((_(' /usr/keys/'), '/usr/keys/'))
        list.append((_(' /var/emu/keys/'), '/var/emu/keys/'))
        list.append((_(' /var/etc/'), '/var/etc/'))
        list.append((_(' /var/etc/emud/'), '/var/etc/emud/'))
        list.append((_(' /var/keys/'), '/var/keys/'))
        self['myMenu'] = MenuList(list)
        self.defaultTEXT = _('Keys will be installed to a selected folder. Pls. do select and press OK.')
        self.text = self.defaultTEXT
        self['myText'] = Label()
        self['about'] = Label(_('DreamOSat Forum\n(www.dreamosat-forum.com)'))
        self['myRedBtn'] = Label(_('Cancel'))
        self['myGreenBtn'] = Label(_('OK'))
        self['myActionsMap'] = ActionMap(['SetupActions', 'ColorActions'],
         {'ok': self.whichFolder,
          'green': self.whichFolder, 
          'red': self.close, 
          'cancel': self.close}, -1)
        self.onShown.append(self.setMyText)

    def lastUpdate(self):
        try:
            URLd = "https://bit.ly/2qNPHqt" #http://pur-e2.club/cam/SoftCam.Key https://bit.ly/2qNPHqt+
            fdate = compat_urlopen(URLd).info().getdate('last-modified')
            return time.strftime('%d-%m-%Y', fdate)
        except IOError:
            self.session.open(MessageBox, _('Cannot connect to the server. Please try later! '), type=MessageBox.TYPE_INFO)
            return 'N/A'

    def setMyText(self):
        self['myText'].setText(self.text)

    def whichFolder(self):
        returnValue = self['myMenu'].l.getCurrentSelection()[1]
        self.PATH = returnValue
        self.process()

    def process(self):
        self.URL2 = "https://bit.ly/2qNPHqt" #http://pur-e2.club/cam/SoftCam.Key https://bit.ly/2qNPHqt+
        self.URL = "https://bit.ly/2Ozz62k" #https://drive.google.com/uc?authuser=0&id=1aujij43w7qAyPHhfBLAN9sE-BZp8_AwI&export=download https://bit.ly/2Ozz62k+
        self.FILE = _('SoftCam.Key')
        if not fileExists(self.PATH):
            os.makedirs(self.PATH)

        web = compat_urlopen(self.URL, context=ctx)
        web2 = compat_urlopen(self.URL2, context=ctx)
        try:
            self.text = _('Conatcting server...')
            if web.code == 200:
                self.deli = web.read()
                self.size = web.info()['Content-Length']
                if int(self.size) > 1024:
                    self.size = int(self.size) // 1024
                self.text = _('File Exists, downloading - %s KB ...') % str(self.size)
                self.download(self.URL, self.PATH + self.FILE, True)
                self.session.open(MessageBox, _('Download finished! Filesize = %s KB. \nPlease restart your oscam.') % str(self.size), type=MessageBox.TYPE_INFO)
            elif web2.code == 200:
                self.deli = web2.read()
                self.size = web2.info()['Content-Length']
                if int(self.size) > 1024:
                    self.size = int(self.size) // 1024
                self.text = _('File Exists, downloading - %s KB ...') % str(self.size)
                self.download(self.URL, self.PATH + self.FILE, True)
                self.session.open(MessageBox, _('Download finished! Filesize = %s KB. \nPlease restart your oscam.') % str(self.size), type=MessageBox.TYPE_INFO)
            else:
                self.text = _("SoftCam.Key doesn't exist on the server. Please try later.")
        except IOError:
            self.session.open(MessageBox, _('Cannot connect to server. Please try later! '), type=MessageBox.TYPE_INFO)

        self.text = self.defaultTEXT
        self.setMyText()

    def download(self, url, filename, overwrite=False):
        try:
            if overwrite:
                print('Try loading: ', str(url), '->', str(filename))
                with open(filename, "wb") as file:
                    file.write(self.deli)
                    file.close()
            else:
                print('Download skipped:', str(url), '->', str(filename))
        except:
            import sys, traceback
            print('-' * 50)
            traceback.print_exc(file=sys.stdout)
            print('-' * 50)
            return False

        return True


